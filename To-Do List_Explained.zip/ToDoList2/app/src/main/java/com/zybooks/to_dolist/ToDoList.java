// Garrick Morley
// ISYS 221-001
// Assignment #6 - To-Do List
// Due: 10/31/2021

// Allow the transfer of data between this class and the rest of the classes
package com.zybooks.to_dolist;

// Import all of the necessary android packages for this class
import android.content.Context;
import android.os.Environment;

// Import all of the necessary java.io packages for this class
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

// Import all of the necessary java.util packages for this class
import java.util.ArrayList;
import java.util.List;

// This statement creates the class "ToDoList"
public class ToDoList {

    // Declare the filename variable as "todolist.txt"
    public static final String FILENAME = "todolist.txt";

    // Initialize these local variables
    private Context mContext;
    private List<String> mList;

    // Creates a function that uses the previous variables to create an array
    public ToDoList(Context context) {
        mContext = context;
        mList = new ArrayList<>();
    }

    // Creates a function that will add a string item to the array
    public void addItem(String item) {
        mList.add(item);
    }

    // Creates a function that will retrieve a string item from the array
    public String[] getItems() {
        String[] items = new String[mList.size()];
        return mList.toArray(items);
    }

    // Creates a function that clears the array, which deletes all of the listed item in the app
    public void clear() {
        mList.clear();
    }

    // Creates a function that will save the data in the array into a file
    public void saveToFile() throws IOException {

        // Write list to internal file
        FileOutputStream outputStream = mContext.openFileOutput(FILENAME, Context.MODE_PRIVATE);
        writeListToStream(outputStream);
    }

    // Creates a function that reads from the file
    public void readFromFile() throws IOException {

        // Initialize the "reader" variable
        BufferedReader reader = null;

        try {
            // Read in list from internal file
            FileInputStream inputStream = mContext.openFileInput(FILENAME);
            reader = new BufferedReader(new InputStreamReader(inputStream));

            // Clears the list using the function from before
            mList.clear();

            // Initialize and add the string variable "line" to the list / array
            String line;
            while ((line = reader.readLine()) != null) {
                mList.add(line);
            }
        }
        // Catch the error if the file is not found
        catch (FileNotFoundException ex) {
            // Ignore
        }
        // If the "reader" variable isn't reading anything, close it and end
        finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    // Creates the function used to download the list / array into a file
    public boolean downloadFile() throws IOException {

        // Make sure SD card is available
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);

            // Create the directory if it doesn't exist
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            // Save list to Downloads directory
            File file = new File(downloadsDir, FILENAME);
            writeListToStream(new FileOutputStream(file));

            return true;
        }

        return false;
    }

    // Creates a function that initializes and uses the "writer" variable to print into the file
    private void writeListToStream(FileOutputStream outputStream) {
        PrintWriter writer = new PrintWriter(outputStream);
        for (String item : mList) {
            writer.println(item);
        }
        // Closes the "writer" variable after it's done printing to the file
        writer.close();
    }

}