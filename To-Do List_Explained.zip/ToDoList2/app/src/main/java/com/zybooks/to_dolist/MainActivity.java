// Garrick Morley
// ISYS 221-001
// Assignment #6 - To-Do List
// Due: 10/31/2021

// Allow the transfer of data between this class and the rest of the classes
package com.zybooks.to_dolist;

// Import all of the necessary android packages for this class
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// Import the java.io package to catch exceptions
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    // Declaring global variables
    private ToDoList mToDoList;
    private EditText mItemEditText;
    private TextView mItemListTextView;

    // This function activates when the program is launched and creates the layout using the activity_main.xml file
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assigning values to the global variables
        mItemEditText = findViewById(R.id.toDoItem);
        mItemListTextView = findViewById(R.id.itemList);

        // Create a new object called "ToDoList"
        mToDoList = new ToDoList(this);
    }

    // This function activates when the program is resumed after a pause
    @Override
    protected void onResume() {
        super.onResume();

        try {
            // Attempt to load a previously saved list
            mToDoList.readFromFile();
            displayList();
        }
        // Catch the error if the prior attempt fails
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // This function handles the pause functionality of the program
    @Override
    protected void onPause() {
        super.onPause();

        try {
            // Save list for later
            mToDoList.saveToFile();
        }
        // Catch the error if the prior attempt fails
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // This function connects a button that's clickable and the statements that occur when clicked
    public void addButtonClick(View view) {

        // Ignore any leading or trailing spaces
        String item = mItemEditText.getText().toString().trim();

        // Clear the EditText so it's ready for another item
        mItemEditText.setText("");

        // Add the item to the list and display it
        if (item.length() > 0) {
            mToDoList.addItem(item);
            displayList();
        }
    }

    // This function displays the list of items that have been added to the list / array
    private void displayList() {

        // Display a numbered list of items
        StringBuffer itemText = new StringBuffer();
        String[] items = mToDoList.getItems();
        for (int i = 0; i < items.length; i++) {
            itemText.append((i + 1) + ". " + items[i] + "\n");
        }

        mItemListTextView.setText(itemText);
    }

    // This function clears the list / array when the corresponding button is clicked
    public void clearButtonClick(View view) {
        mToDoList.clear();
        displayList();
    }

    // Creates and initializes the private final variable "REQUEST_WRITE_CODE"  to 0
    private final int REQUEST_WRITE_CODE = 0;

    // This function activates when the download button is clicked and downloads the list to a file
    public void downloadButtonClick(View view) {
        // TODO: Save list to SD card
        // This tests to see if the app has permission to use external storage for the download
        if (PermissionsUtil.hasPermissions(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, R.string.write_rationale, REQUEST_WRITE_CODE)) {
            try {
                // If permission is granted, use the "downloadFile" function to download the file
                if (mToDoList.downloadFile()) {
                    // If the download worked use the toast import to make a quick popup saying so
                    Toast.makeText(this, R.string.download_successful, Toast.LENGTH_SHORT).show();
                }
                else {
                    // If the download failed use the toast import again to let the user know
                    Toast.makeText(this, R.string.download_failed, Toast.LENGTH_LONG).show();
                }
              // Mandatory catch function in case of error, also uses the toast import to display info
            } catch (IOException e) {
                Toast.makeText(this, R.string.download_failed, Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }
    }

    // This function activates when we get the results of the permission request from the user
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        // I had to add this super request in order to get this section of the given code to function properly
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // This switch case function operates using the "requestCode" variable
        switch (requestCode) {
            // If the "REQUEST_WRITE_CODE" boolean variable from before is true then continue
            case REQUEST_WRITE_CODE: {
                // This if statement checks if permission to use external storage was granted
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, so download the list to SD card
                    downloadButtonClick(null);
                }
                return;
            }
        }
    }
}